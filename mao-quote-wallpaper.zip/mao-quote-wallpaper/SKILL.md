---
name: mao-quote-wallpaper
description: >
  Generate a desktop wallpaper featuring a randomly selected Mao Zedong
  quotation with calligraphic typography, source citations, and annotations.
  Also applies the generated wallpaper as the Windows desktop background.
  Use this skill when the user asks for service quote wallpaper,
  service wallpaper, desktop wallpaper with a service theme, or daily inspiration
  from Mao Zedong's Selected Works.
  Trigger keywords include: 毛选, 毛主席语录, 毛语录, 桌面壁纸,
  Mao wallpaper, 毛选壁纸.
agent_created: true
---

# 毛选壁纸 — 每日语录桌面

Generate a calligraphic desktop wallpaper from
_Selected Works of Mao Zedong_ (毛泽东选集), then apply it as the
Windows desktop background.

## Workflow

### 1. Pick a quote

Read `references/quotes.md` to obtain the full quote library. Randomly
select one entry. Each entry provides the exact text for every required
parameter (quote, volume, article, date, vertical-year, note).

When picking, rotate through the library so that consecutive runs avoid
repeating the same quote. Track the last-used index in a note; if no
prior note exists, start at random.

### 2. Generate the wallpaper PNG

Run the bundled script with the selected quote's parameters:

```bash
python scripts/gen_wallpaper.py \
  --quote "星星之火，可以燎原" \
  --volume "《毛泽东选集》第一卷" \
  --article "《星星之火，可以燎原》" \
  --date "一九三〇年一月五日" \
  --vertical-year "一九三〇" \
  --note "毛泽东致林彪的复信。针对当时党内..." \
  --output "<output_dir>/mao_quote_wallpaper.png"
```

All parameters are required. The script auto-detects available Chinese
fonts: prefers 汉仪黄科行书简, falls back to 华文行楷 if not found.

The script also auto-calculates font size based on quote length:
- <=6 chars → 220px
- <=10 chars → 190px
- <=15 chars → 150px
- <=20 chars → 110px
- <=30 chars → 80px
- >30 chars → 60px

### 3. Apply as Windows wallpaper

After the PNG is generated, apply it as the desktop background using
the Win32 API via Python `ctypes`:

```python
import ctypes
path = r"<output_dir>\mao_quote_wallpaper.png"
ctypes.windll.user32.SystemParametersInfoW(20, 0, path, 3)
```

### 4. Optional — Set up a daily automation

To rotate the wallpaper daily at 8:00 AM, create an automation with:
- Schedule: `FREQ=DAILY;BYHOUR=8;BYMINUTE=0`
- Prompt: "Generate a wallpaper using the 毛选壁纸 skill with a random quote and apply it as the Windows desktop background"

## Design Specification

Every generated wallpaper follows this visual spec:

| Parameter      | Value                                          |
|----------------|------------------------------------------------|
| Resolution     | 1920×1080                                      |
| Background     | Warm cream / parchment radial gradient         |
| Main quote     | Cinnabar red gradient (top→bottom: bright→dark)|
| Font (primary) | 汉仪黄科行书简 (auto-detect, fallback: 华文行楷) |
| Glow           | Warm amber halo centered behind text           |
| Seal stamp     | Red "毛选" stamp at top-right                   |
| Decorative     | "毛主席语录" label top-left, year vertical left-bottom |
| Citation       | Right-bottom: volume, article, date, annotation |

## Configuration

The following paths are used for font resolution. If they differ on a
user's machine, update them before running:

| Font Type      | Primary Path                                                                 | Fallback                     |
|----------------|------------------------------------------------------------------------------|------------------------------|
| Calligraphy    | `C:/Users/admin/AppData/Local/Microsoft/Windows/Fonts/hanyihuangkexingshujian.ttf` | `C:/Windows/Fonts/STXINGKA.TTF` |
| KaiTi          | `C:/Windows/Fonts/STKAITI.TTF`                                               | any serif font               |
| HeiTi / YaHei  | `C:/Windows/Fonts/msyh.ttc`                                                  | any sans-serif font          |

## Dependencies

- Python 3.7+ with **Pillow** (`pip install Pillow`)
- Chinese fonts installed (see configuration above)
