# -*- coding: utf-8 -*-
"""
毛选语录艺术壁纸生成器
用法: python gen_wallpaper.py --quote "语录原文" --volume "卷次" --article "篇名" \\
      --date "日期" --vertical-year "年份竖排" --note "注释" --output "输出路径.png"

可选参数:
  --font         主字体路径 (默认: 自动检测汉仪黄科行书简 > 华文行楷)
  --font-kaiti   楷体路径 (默认: C:/Windows/Fonts/STKAITI.TTF)
  --font-hei     黑体路径 (默认: C:/Windows/Fonts/msyh.ttc)
  --font-size    主语录字号 (默认: 自动计算)
  --width        壁纸宽度 (默认: 1920)
  --height       壁纸高度 (默认: 1080)
"""
import argparse, math, random, os, sys
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageEnhance

# ======================== 字体自动检测 ========================
def detect_calligraphy_font():
    """检测可用的书法字体"""
    candidates = [
        "C:/Users/admin/AppData/Local/Microsoft/Windows/Fonts/hanyihuangkexingshujian.ttf",
        "C:/Windows/Fonts/STXINGKA.TTF",
    ]
    for p in candidates:
        if os.path.exists(p):
            return p
    # 宽搜索
    for root in ["C:/Windows/Fonts", "C:/Users/admin/AppData/Local/Microsoft/Windows/Fonts"]:
        if os.path.isdir(root):
            for f in os.listdir(root):
                lower = f.lower()
                if any(kw in lower for kw in ["huang", "xingshu", "xingka", "kaiti", "simsun"]):
                    if lower.endswith((".ttf", ".ttc", ".otf")):
                        return os.path.join(root, f)
    raise FileNotFoundError("No calligraphy font found. Install 汉仪黄科行书简 or 华文行楷.")

def detect_kaiti_font():
    for p in ["C:/Windows/Fonts/STKAITI.TTF", "C:/Windows/Fonts/simkai.ttf"]:
        if os.path.exists(p):
            return p
    return detect_calligraphy_font()  # fallback

def detect_hei_font():
    for p in ["C:/Windows/Fonts/msyh.ttc", "C:/Windows/Fonts/simhei.ttf"]:
        if os.path.exists(p):
            return p
    return detect_calligraphy_font()  # fallback

# ======================== 配置 ========================
def parse_args():
    p = argparse.ArgumentParser(description="毛选语录艺术壁纸生成器")
    p.add_argument("--quote", required=True, help="主语录文本")
    p.add_argument("--volume", required=True, help="出处卷次，如《毛泽东选集》第一卷")
    p.add_argument("--article", required=True, help="出处篇名，如《星星之火，可以燎原》")
    p.add_argument("--date", required=True, help="书写日期，如 一九三〇年一月五日")
    p.add_argument("--vertical-year", required=True, help="左下角竖排年份，如 一九三〇")
    p.add_argument("--note", required=True, help="段落注释正文")
    p.add_argument("--output", default=None, help="输出PNG路径 (默认: 当前目录/mao_quote_wallpaper.png)")
    p.add_argument("--font", default=None, help="主书法字体路径")
    p.add_argument("--font-kaiti", default=None, help="楷体路径")
    p.add_argument("--font-hei", default=None, help="黑体/雅黑路径")
    p.add_argument("--font-size", type=int, default=None, help="主文字号 (自动计算)")
    p.add_argument("--width", type=int, default=1920, help="宽度")
    p.add_argument("--height", type=int, default=1080, help="高度")
    p.add_argument("--seed", type=int, default=None, help="随机种子")
    return p.parse_args()

# ======================== 布局计算 ========================
def calc_font_size(quote, max_width, font_path):
    """根据语文字数自动计算最佳字号"""
    char_count = len(quote)
    if char_count <= 6:
        return 220
    elif char_count <= 10:
        return 190
    elif char_count <= 15:
        return 150
    elif char_count <= 20:
        return 110
    elif char_count <= 30:
        return 80
    else:
        return 60

# ======================== 绘制 ========================
def generate(args):
    W, H = args.width, args.height
    if args.seed is not None:
        random.seed(args.seed)

    # 字体
    FONT_MAIN = args.font or detect_calligraphy_font()
    FONT_KAITI = args.font_kaiti or detect_kaiti_font()
    FONT_HEI = args.font_hei or detect_hei_font()
    font_size = args.font_size or calc_font_size(args.quote, W * 0.75, FONT_MAIN)

    # ---- 明亮配色 ----
    BG_CENTER = (250, 245, 232)
    BG_EDGE   = (225, 215, 195)
    INK_TOP   = (200, 35, 35)
    INK_MID   = (160, 20, 20)
    INK_BOT   = (110, 16, 16)
    GLOW_WARM = (230, 180, 40)
    GLOW_AMBER = (210, 145, 25)
    SEAL_RED  = (200, 30, 30)
    LINE_GOLD = (160, 120, 50)
    NOTE_TITLE = (140, 100, 40)
    NOTE_BODY  = (80, 55, 30)
    SPARK_WARM = (220, 150, 30)

    print("=" * 60)
    print(f"  语录: {args.quote}")
    print(f"  字体: {FONT_MAIN}")
    print(f"  字号: {font_size}px")
    print(f"  尺寸: {W}x{H}")
    print("=" * 60)

    # ======================== 1. 背景 ========================
    print(">>> 1/6  绘制背景...")
    img = Image.new('RGB', (W, H), BG_EDGE)
    draw = ImageDraw.Draw(img)

    for y in range(H):
        t = abs(y - H * 0.46) / (H * 0.52)
        t = min(t, 1.0)
        ease = 3 * t*t - 2 * t*t*t
        r = int(BG_CENTER[0] * (1 - ease) + BG_EDGE[0] * ease)
        g = int(BG_CENTER[1] * (1 - ease) + BG_EDGE[1] * ease)
        b = int(BG_CENTER[2] * (1 - ease) + BG_EDGE[2] * ease)
        draw.line([(0, y), (W, y)], fill=(r, g, b))

    texture = Image.new('L', (W, H), 128)
    texture_draw = ImageDraw.Draw(texture)
    for _ in range(3000):
        x = random.randint(0, W - 1)
        y = random.randint(0, H - 1)
        v = random.randint(124, 132)
        texture_draw.point((x, y), fill=v)
    texture = texture.filter(ImageFilter.GaussianBlur(0.8))
    texture_rgb = Image.merge('RGB', (texture, texture, texture))
    img = Image.blend(img, texture_rgb, 0.06)

    # ======================== 2. 光晕 ========================
    print(">>> 2/6  绘制光晕...")
    glow_layer = Image.new('RGB', (W, H), BG_CENTER)
    glow_draw = ImageDraw.Draw(glow_layer)
    cx, cy = W // 2, int(H * 0.46)

    for radius in range(550, 0, -10):
        progress = 1 - radius / 550
        intensity = progress ** 2.0
        r = int(255 * (1 - intensity) + 235 * intensity)
        g = int(245 * (1 - intensity) + 200 * intensity)
        b = int(232 * (1 - intensity) + 130 * intensity)
        glow_draw.ellipse([cx - radius, cy - radius, cx + radius, cy + radius], fill=(r, g, b))

    glow_layer = glow_layer.filter(ImageFilter.GaussianBlur(120))
    img = Image.blend(img, glow_layer, 0.6)

    # ======================== 3. 粒子 ========================
    print(">>> 3/6  撒播粒子...")
    spark_layer = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    spark_draw = ImageDraw.Draw(spark_layer)

    for _ in range(60):
        x = random.randint(0, W)
        y = random.randint(int(H * 0.35), H)
        size = random.uniform(1.5, 4)
        brightness = random.uniform(0.25, 0.75)
        core_r = int(220 * brightness + 35 * (1 - brightness))
        core_g = int(150 * brightness + 180 * (1 - brightness))
        core_b = int(30 * brightness + 200 * (1 - brightness))
        alpha_core = int(150 * brightness)
        spark_draw.ellipse([x - size, y - size, x + size, y + size], fill=(core_r, core_g, core_b, alpha_core))
        halo_size = size * 3
        halo_alpha = int(40 * brightness)
        spark_draw.ellipse([x - halo_size, y - halo_size, x + halo_size, y + halo_size], fill=(core_r, core_g, core_b, halo_alpha))

    spark_layer = spark_layer.filter(ImageFilter.GaussianBlur(1.5))
    img = Image.alpha_composite(img.convert('RGBA'), spark_layer).convert('RGB')

    # ======================== 4. 主语录 ========================
    print(">>> 4/6  绘制主语录...")
    quote = args.quote
    font_main = ImageFont.truetype(FONT_MAIN, font_size)

    bbox = font_main.getbbox(quote)
    text_w = bbox[2] - bbox[0]
    text_h = bbox[3] - bbox[1]
    text_x = (W - text_w) // 2 - bbox[0]
    text_y = cy - text_h // 2 - bbox[1]

    # 光晕
    glow_mask = Image.new('L', (W, H), 0)
    glow_mask_draw = ImageDraw.Draw(glow_mask)
    glow_mask_draw.text((text_x, text_y), quote, font=font_main, fill=255)

    glow_blurred = glow_mask.filter(ImageFilter.GaussianBlur(25))
    glow_color = Image.new('RGB', (W, H), GLOW_WARM)
    img = Image.composite(glow_color, img, ImageEnhance.Brightness(glow_blurred).enhance(0.3))

    glow_blurred2 = glow_mask.filter(ImageFilter.GaussianBlur(10))
    glow_color2 = Image.new('RGB', (W, H), GLOW_AMBER)
    img = Image.composite(glow_color2, img, ImageEnhance.Brightness(glow_blurred2).enhance(0.15))

    # 朱砂红渐变
    gradient = Image.new('RGB', (W, H), BG_CENTER)
    for y in range(H):
        t = (y - text_y) / text_h
        t = max(0, min(1, t))
        if t < 0.35:
            tt = t / 0.35
            r = int(INK_TOP[0] * (1 - tt) + INK_MID[0] * tt)
            g = int(INK_TOP[1] * (1 - tt) + INK_MID[1] * tt)
            b = int(INK_TOP[2] * (1 - tt) + INK_MID[2] * tt)
        else:
            tt = (t - 0.35) / 0.65
            r = int(INK_MID[0] * (1 - tt) + INK_BOT[0] * tt)
            g = int(INK_MID[1] * (1 - tt) + INK_BOT[1] * tt)
            b = int(INK_MID[2] * (1 - tt) + INK_BOT[2] * tt)
        ImageDraw.Draw(gradient).line([(0, y), (W, y)], fill=(r, g, b))

    img.paste(gradient, (0, 0), glow_mask)

    # 阴影
    shadow_mask = Image.new('L', (W, H), 0)
    shadow_draw = ImageDraw.Draw(shadow_mask)
    shadow_draw.text((text_x + 2, text_y + 2), quote, font=font_main, fill=60)
    shadow_blurred = shadow_mask.filter(ImageFilter.GaussianBlur(2))
    shadow_color = Image.new('RGB', (W, H), BG_EDGE)
    img = Image.composite(shadow_color, img, ImageEnhance.Brightness(shadow_blurred).enhance(0.4))

    # ======================== 5. 装饰 ========================
    print(">>> 5/6  绘制装饰...")
    draw = ImageDraw.Draw(img)

    # 分隔线
    line_y = text_y + text_h + 55
    line_cx = W // 2
    line_half = 140
    for x in range(line_cx - line_half, line_cx + line_half):
        t = abs(x - line_cx) / line_half
        alpha = int(140 * (1 - t))
        if alpha > 0:
            draw.point((x, line_y), fill=LINE_GOLD)
    draw.ellipse([line_cx - 4, line_y - 4, line_cx + 4, line_y + 4], fill=LINE_GOLD)

    # 印章
    seal_x, seal_y = W - 130, 70
    seal_size = 80
    seal_layer = Image.new('RGBA', (seal_size + 20, seal_size + 20), (0, 0, 0, 0))
    seal_draw = ImageDraw.Draw(seal_layer)
    seal_draw.rounded_rectangle(
        [5, 5, seal_size + 10, seal_size + 10], radius=8,
        outline=(*SEAL_RED, 210), width=3
    )
    font_seal = ImageFont.truetype(FONT_MAIN, 28)
    seal_draw.text((seal_size // 2 + 5, seal_size // 2 + 5), "毛选", font=font_seal, fill=(*SEAL_RED, 210), anchor='mm')
    img.paste(seal_layer, (seal_x, seal_y), seal_layer)

    # 顶部装饰
    font_deco = ImageFont.truetype(FONT_HEI, 14)
    deco_text = "毛  主  席  语  录"
    deco_color = (160, 120, 60)
    draw.line([(80, 93), (115, 93)], fill=deco_color, width=1)
    draw.text((128, 85), deco_text, font=font_deco, fill=deco_color)

    # 左下角竖排年份
    font_year = ImageFont.truetype(FONT_KAITI, 15)
    year_text = args.vertical_year
    year_color = (130, 95, 55)
    for i, ch in enumerate(year_text):
        draw.text((85, H - 180 + i * 24), ch, font=font_year, fill=year_color)

    # ======================== 6. 出处与注释 ========================
    print(">>> 6/6  绘制出处与注释...")
    font_source      = ImageFont.truetype(FONT_KAITI, 22)
    font_source_book = ImageFont.truetype(FONT_KAITI, 24)
    font_note_label  = ImageFont.truetype(FONT_HEI, 16)
    font_note        = ImageFont.truetype(FONT_HEI, 17)

    note_x = W - 80
    note_y_start = H - 280
    max_note_width = 360

    source_lines = [
        (args.volume, font_source_book, LINE_GOLD),
        (args.article, font_source, NOTE_TITLE),
        (args.date, font_source, NOTE_TITLE),
    ]

    current_y = note_y_start
    for text, font, color in source_lines:
        bbox = font.getbbox(text)
        tw = bbox[2] - bbox[0]
        draw.text((note_x - tw, current_y), text, font=font, fill=color)
        current_y += bbox[3] - bbox[1] + 10

    current_y += 8
    draw.line([(note_x - max_note_width, current_y), (note_x, current_y)], fill=LINE_GOLD, width=1)
    current_y += 16

    label_text = "段  落  注  释"
    bbox = font_note_label.getbbox(label_text)
    draw.text((note_x - (bbox[2] - bbox[0]), current_y), label_text, font=font_note_label, fill=LINE_GOLD)
    current_y += 25

    def wrap_text(text, font, max_width):
        lines = []
        current = ""
        for ch in text:
            test = current + ch
            bbox = font.getbbox(test)
            if bbox[2] - bbox[0] > max_width and current:
                lines.append(current)
                current = ch
            else:
                current = test
        if current:
            lines.append(current)
        return lines

    note_lines = wrap_text(args.note, font_note, max_note_width)
    for line in note_lines:
        bbox = font_note.getbbox(line)
        tw = bbox[2] - bbox[0]
        draw.text((note_x - tw, current_y), line, font=font_note, fill=NOTE_BODY)
        current_y += bbox[3] - bbox[1] + 8

    # ======================== 暗角 ========================
    vignette = Image.new('L', (W, H), 0)
    vignette_draw = ImageDraw.Draw(vignette)
    vignette_draw.rectangle([0, 0, W, H], fill=255)
    for r in range(0, 500, 5):
        alpha = int(r / 500 * 100)
        vignette_draw.rectangle(
            [r, int(r * H / W), W - r, H - int(r * H / W)],
            outline=255 - alpha
        )
    vignette = vignette.filter(ImageFilter.GaussianBlur(200))
    vignette_overlay = Image.new('RGB', (W, H), (210, 195, 165))
    img = Image.composite(img, vignette_overlay, vignette)

    # ======================== 保存 ========================
    output_path = args.output or os.path.join(os.path.dirname(__file__), "mao_quote_wallpaper.png")
    img.save(output_path, 'PNG', quality=95)
    print(f"\nDone: {output_path}  ({W}x{H})")
    return output_path

if __name__ == "__main__":
    args = parse_args()
    generate(args)
